insert into tarefa (id, titulo, descricao, finalizada, dt_previsao, dt_finalizacao) values (1, 'Dominar o mundo', 'Dominar o mundo inteiro', false, '2050-12-12', null);
